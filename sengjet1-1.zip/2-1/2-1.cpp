#include <stdio.h>

int main() {
    char c, c_array[100];
    int i, i_array[100];
    short s, s_array[100];
    float f, f_array[100];
    long l, l_array[100];

    printf("\n char c ũ�� = %zu \t: char c_array ũ�� = %zu", sizeof(c), sizeof(c_array));
    printf("\n int i ũ�� = %zu \t: int i_array ũ�� = %zu", sizeof(i), sizeof(i_array));
    printf("\n short s ũ�� = %zu \t: short s_array ũ�� = %zu", sizeof(s), sizeof(s_array));
    printf("\n float f ũ�� = %zu \t: float f_array ũ�� = %zu", sizeof(f), sizeof(f_array));
    printf("\n long l ũ�� = %zu \t: long l_array ũ�� = %zu", sizeof(l), sizeof(l_array));

    getchar();
    return 0;
}

